
class NoInternetException(Exception):
    pass


def get_path(resource_path, root_dir: str):
    return root_dir + '/resources/' + resource_path

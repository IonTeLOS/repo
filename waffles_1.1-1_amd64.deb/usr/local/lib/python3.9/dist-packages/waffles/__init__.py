__version__ = '1.1'
__app_name__ = 'Waffles'

import os
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
LOGS_PATH = '/tmp/{}/logs'.format(__app_name__)
